var MidiWriter = midiWriteJs;
var trackleft = new MidiWriter.Track();
var trackright = new MidiWriter.Track();
var trackdrum = new MidiWriter.Track();
var globalUID = 0;
function generatePattern(seed, recursions) {
	var original = false;
	if (recursions < 2) {
		seed.forEach(function(e, i, arr) {
			arr[i] = String(globalUID) + e;
		});
		globalUID++;
		return seed;
	}
	if (typeof seed !== "object") {
		seed = seed.split("");
		globalUID = 0;
		var original = true;
	}
	var replaceVal = {};
	for (var i = 0; i < seed.length; i++) {
		if (!replaceVal[JSON.stringify(seed[i])]) replaceVal[JSON.stringify(seed[i])] = generatePattern(opt[~~(Math.random()*opt.length)].split(""), recursions-1);
	}
	for (var i = 0; i < seed.length; i++) {
		seed[i] = replaceVal[JSON.stringify(seed[i])];
	}
	if (!original) return seed;
	else return {
		array: seed,
		result: seed.join(",").split(",").join("-"),
		UIDmax: globalUID,
	};
}
function generateChord(key, s) {
	var notes = [];
	var chords = [
		[0, 4, 7],
		[2, 5, 9],
		[4, 7, 11],
		[5, 9, 12],
		[7, 11, 14],
		[9, 12, 16],
	];
	notes = chords[~~(Math.random()*chords.length)];
	var shift = ~~(Math.random()*3)
	notes.forEach(function(e, i, arr){
		arr[i] += key + 51 + ((shift == 1 && i == 0) ? 12 : 0) + ((shift == 2 && i == 2) ? -12 : 0);
	});
	return notes;
};
var opt = [
	"ABBC",
	"AABB",
	"AABC",
	"ABAC",
	"ABCD",
	"ABCC",
	"ABCB",
	"ABCA",
	"ABBB",
	"ABBA",
	"ABAB",
	"AAAB",
];
function generateSong(seed, recursions, key) {
	var tempo = ~~((80+Math.random()*80)/5)*5
	trackleft.setTempo(tempo);
	trackright.setTempo(tempo);
	if (typeof key === "undefined") key = ~~(Math.random()*12);
	var base = generatePattern(seed, recursions);
	var chords = [];
	var r = 4+Math.random()*2;
	for (var i = 0; i < r; i++) {
		var c = generateChord(key);
		if (!JSON.stringify(chords).includes(JSON.stringify(c))) chords.push(c);
	}
	var chordAssign = {};
	var chordFunctionAssign = {};
	for (var i = 0; i < base.UIDmax; i++) {
		chordAssign[i + "A"] = generateChordSnippet(chords);
		chordAssign[i + "B"] = generateChordSnippet(chords);
		chordAssign[i + "C"] = generateChordSnippet(chords);
		chordAssign[i + "D"] = generateChordSnippet(chords);
		chordFunctionAssign[i + "A"] = generateChordFunction();
		chordFunctionAssign[i + "B"] = chordFunctionAssign[i + "A"];
		chordFunctionAssign[i + "C"] = chordFunctionAssign[i + "A"];
		chordFunctionAssign[i + "D"] = chordFunctionAssign[i + "A"];
	}
	trackleft.addEvent(new MidiWriter.ProgramChangeEvent({instrument: 2}));
	trackright.addEvent(new MidiWriter.ProgramChangeEvent({instrument: 1}));
	//trackdrum.addEvent(new MidiWriter.ProgramChangeEvent({instrument: 118}));
	for (var i = 0; i < base.result.split("-").length; i++) {
		var currentTime = 0;
		var ch = chordAssign[base.result.split("-")[i]];
		for (var j = 0; j < ch.time.length; j++) {
			applyFunctionToTimedChord(shiftArray(ch.chords[j], -12), ch.time[j], chordFunctionAssign[base.result.split("-")[i]], currentTime);
			currentTime += timeToString(ch.time[j]);
		}
	}
	var melodyAssign = {};
	for (var i = 0; i < base.UIDmax; i++) {
		melodyAssign[i + "A"] = generateMelodySnippetFromChords(chordAssign[i + "A"], key);
		melodyAssign[i + "B"] = generateMelodySnippetFromChords(chordAssign[i + "B"], key);
		melodyAssign[i + "C"] = generateMelodySnippetFromChords(chordAssign[i + "C"], key);
		melodyAssign[i + "D"] = generateMelodySnippetFromChords(chordAssign[i + "D"], key);
	}
	for (var i = 0; i < base.result.split("-").length; i++) {
		var ch = melodyAssign[base.result.split("-")[i]];
		for (var j = 0; j < ch.length; j++) {
			trackright.addEvent(
				[
					new MidiWriter.NoteEvent({pitch: shiftArray(ch[j].note, 12), duration: ch[j].time, velocity: 100})
				],
				function(e, i) {
					return {sequential: false};
				}
			);
		}
	}
	/*for (var i = 0; i < base.result.split("-").length; i++) {
		for (var j = 0; j < ch.length; j++) {
			trackdrum.addEvent(
				[
					new MidiWriter.NoteEvent({pitch: ~~(Math.random()*88), duration: "4", velocity: 100, channel: 10})
				],
				function(e, i) {
					return {sequential: false};
				}
			);
		}
	}*/
	
	var write = new MidiWriter.Writer([trackleft, trackright, trackdrum]);
	console.log(write.dataUri());
	return write.dataUri();
}
function shiftArray(arr, e) {
	var a = JSON.parse(JSON.stringify(arr));
	for (var i = 0; i < arr.length; a[i++] += e);
	return a;
}
function generateChordSnippet(chords) {
	var types = [
		["dd2", "8"],
		["2", "2"],
		["2", "2"],
		["2", "2"],
		["2", "2"],
		["d2", "4"],
		["4", "2", "4"],
		["d4", "8", "d4", "8"],
		["1"],
		["1"],
		["1"],
		["1"],
	];
	var r = types[~~(Math.random()*types.length)];
	var r2 = [];
	for (var i = 0; i < r.length; i++) {
		r2.push(chords[~~(Math.random()*chords.length)])
	}
	return {time: r, chords: r2};
}
function generateMelodySnippetFromChords(chordsnippet, key) {
	var exportArr = [];
	for (var i = 0; i < chordsnippet.time.length; i++) {
		exportArr.push(...generateMelodyFromTimedChord(chordsnippet.chords[i], chordsnippet.time[i], key));
	}
	return exportArr;
}
function applyFunctionToTimedChord(chord, time, func, startTime) {
	chord = JSON.parse(JSON.stringify(chord));
	chord.sort((a, b) => b - a);
	var totalTime = 0;
	var i = 0;
	var j = 0;
	var k = 0;
	while (k < startTime) {
		k += func[j].time;
		j++;
	}
	if (k-startTime > 0) {
		j--
		var nts = JSON.parse(JSON.stringify(func[j].notes));
		nts.forEach(function(e, i, arr){
			arr[i] = chord[arr[i].note] + (arr[i].shift*12);
		})
		trackleft.addEvent(
			[
				new MidiWriter.NoteEvent({pitch: nts, duration: timeToString(Math.min(k-startTime, time))})
			],
			function(e, i) {
				return {sequential: false};
			}
		);
		console.log("added: ", Math.min(k-startTime, time));
		totalTime += Math.min(k-startTime, time);
		i+= Math.min(k-startTime, time);
		j++;
	}
	time = stringToTime(time);
	while (i < time) {
		var l = func[j].time
		if (i + l > time) {
			l = time - i;
			i += l;
		} else {
			i += l;
		}
		var nts = JSON.parse(JSON.stringify(func[j].notes));
		nts.forEach(function(e, i, arr){
			arr[i] = chord[arr[i].note] + (arr[i].shift*12);
		})
		trackleft.addEvent(
			[
				new MidiWriter.NoteEvent({pitch: nts, duration: timeToString(l)})
			],
			function(e, i) {
				return {sequential: false};
			}
		);
		totalTime += l;
		j++;
		j%=func.length;
	}
	if (totalTime != time) console.error("added a total of", totalTime, "when", time, "was required with i=", i);
}
function generateMelodyFromTimedChord(chord, time, key) {
	chord.sort((a, b) => b - a);
	var possibleNotes = [];
	var ticks = stringToTime(time);
	var base = chord[2] - key - 51;
	var top = chord[0] - key - 51;
	var notes = [
		-7,
		-5,
		-3,
		-1,
		0,
		2,
		4,
		5,
		7,
		9,
		11,
		12,
		14,
		16,
		17,
		19,
		21,
		23,
	];
	var baseIndex = notes.indexOf(base);
	var topIndex = notes.indexOf(top);
	if (baseIndex == -1 || topIndex == -1) {
		throw "oh no somethings gone terribly wrong please send help, looking for code: " + base + ", " + top;
	}
	for (var i = baseIndex-1; i < topIndex+2; i++) {
		possibleNotes.push(notes[i]);
	}
	var lengths = [];
	var currentLength = 0;
	for (var i = 0; i < ticks; i++) {
		if (currentLength > 1) {
			if (0.5 - (0.25*(currentLength%2)) > Math.random()) {
				lengths.push(currentLength);
				currentLength = 0;
			}
		}
		currentLength++;
	}
	lengths.push(currentLength);
	var exportNotes = [];
	for (var i = 0; i < lengths.length; i++) {
		if (i == 0) {
			exportNotes.push({
				time: timeToString(lengths[i]),
				note: chord[~~(Math.random()*chord.length)],
			})
		} else {
			var n = possibleNotes[~~(Math.random()*possibleNotes.length)]%12 + key + 51;
			while (chord.includes(n+1) || chord.includes(n-1)) {
				n = possibleNotes[~~(Math.random()*possibleNotes.length)]%12 + key + 51;
			}
			var n2 = chord[~~(Math.random()*chord.length)];
			exportNotes.push({
				time: timeToString(lengths[i]),
				note: (Math.random() < 0.35 && Math.abs(n-n2)>2) ? [n, n2] : [n],
			})
		}
	}
	return exportNotes;
}
function stringToTime(e) {
	var map = {
		"dd2": 14,
		"8": 2,
		"2": 8,
		"d2": 12,
		"4": 4,
		"1": 16,
		"d4": 6,
	};
	return map[e];
}
function timeToString(e) {
	return "T" + (e/16*128*4);
}
function generateChordFunction() {
	function e(a) {
		s = [];
		for (var i = 0; i < a; i++) {
			s.push({note: ~~(Math.random()*3), shift: -~~(Math.random()*2)})
		}
		return s;
	}
	var beats = 2**(~~(Math.random()*4)+1);
	var lengths = [
		1,
		2,
		2,
		2,
		2,
		4,
		4,
		4,
		4,
		4,
		4,
		8,
	];
	var exportPattern = [];
	var i = 0;
	while (i < beats) {
		var l = lengths[~~(lengths.length*Math.random())];
		exportPattern.push({time: l, notes: e([1, 1, 1, 1, 1, 1, 2, 2, 2, 3][~~(Math.random()*6)])});
		i += l;
		if (i > beats) {
			i -= l;
			exportPattern.pop();
			l = beats-i;
			exportPattern.push({time: l, notes: e(~~(Math.random()*2+2))});
			break;
		}
	}
	return exportPattern;
}