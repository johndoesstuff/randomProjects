var countries;
var data;
var img = document.getElementById("i");
var canvas = document.getElementById("c");
var ctx = canvas.getContext("2d");
fetch("https://api.covid19api.com/all")
.then((resp) => resp.json())
.then(function(d) {
	data = d;
	console.log("fetched");
	renderDay(0, data);
})
function renderDay(day, data) {
	ctx.drawImage(img, 0, 0);
	countries = {};
	for (var i = 0; i < data.length; i++) {
		var c = data[i].Country + (data[i].Province ? ", " : "") + data[i].Province;
		if (countries[c] === undefined) countries[c] = {
			confirmed: {date: 0, count: 0},
			deaths: {date: 0, count: 0},
			recovered: {date: 0, count: 0},
			coords: [data[i].Lat, data[i].Lon],
		};
		if ((new Date(data[i].Date)).getTime() > countries[c][data[i].Status].date && (new Date(data[i].Date)).getTime() < (new Date((new Date()).getTime()-day*86400000)).getTime()) {
			countries[c][data[i].Status].date = (new Date(data[i].Date)).getTime();
			countries[c][data[i].Status].count = data[i].Cases// + (Math.random()/100000);
		}
	}
	var keys = Object.keys(countries);
	for (var i = 0; i < keys.length; i++) {
		ctx.lineWidth = 1;
		var coords = mapCoords(countries[keys[i]].coords);
		ctx.fillStyle = "red";
		ctx.strokeStyle = "red";
		ctx.globalAlpha = 0.5;
		var d = 10;
		ctx.beginPath();
		ctx.arc(coords[1], coords[0], Math.sqrt(countries[keys[i]].confirmed.count/Math.PI)/2.5, 0, 2 * Math.PI);
		ctx.fill();
		ctx.globalAlpha = 1;
		ctx.stroke();
		ctx.beginPath();
		ctx.arc(coords[1], coords[0], Math.sqrt(countries[keys[i]].recovered.count/Math.PI)/2.5, 0, 2 * Math.PI);
		ctx.strokeStyle = "#87CEEB";
		ctx.stroke();
		ctx.beginPath();
		ctx.arc(coords[1], coords[0], Math.sqrt(countries[keys[i]].deaths.count/Math.PI)/2.5, 0, 2 * Math.PI);
		ctx.strokeStyle = "black";
		ctx.stroke();
		
	}
	var total = {
		confirmed: 0,
		deaths: 0,
		recovered: 0,
	};
	for (var i = 0; i < keys.length; i++) {
		total.confirmed += countries[keys[i]].confirmed.count;
		total.deaths += countries[keys[i]].deaths.count;
		total.recovered += countries[keys[i]].recovered.count;
	}
	ctx.fillStyle = "#2b2b2b";
	ctx.fillRect(0, 1080, 1920, 350);
	ctx.fillStyle = "white";
	ctx.font = "70px Courier";
	ctx.fillText((new Date((new Date()).getTime()-day*86400000)).toLocaleDateString(), 1475, 1027);
	ctx.font = "80px Courier";
	ctx.fillText("Confirmed: " + total.confirmed, 50, 1080+100);
	ctx.fillText("Recovered: " + total.recovered, 50, 1080+200);
	ctx.fillText("Dead: " + total.deaths, 50, 1080+300);
	ctx.fillText("Rec/Death: " + Math.round(total.recovered/total.deaths*1000)/1000, 1920/2, 1080+100);
	ctx.fillText("Death/Conf: " + Math.round(total.deaths/total.confirmed*1000)/1000, 1920/2, 1080+200);
	ctx.fillText("Death %: " + Math.round(total.deaths/(total.confirmed+total.recovered)*100000)/1000, 1920/2, 1080+300);
	var cases = [];
	for (var i = 0; i < keys.length; i++) {
		cases.push(countries[keys[i]].confirmed.count + countries[keys[i]].deaths.count + countries[keys[i]].recovered.count);
	}
	var m = Math.max(...cases);
	for (var i = 0; i < cases.length; i++) {
		cases[i] /= m;
	}
	cases.sort();
	for (var i = 0; i < cases.length; i++) {
		cases[i] = Math.round(cases[i]*m);
	}
	cases.reverse();
	var c = [];
	for (var k = 0; k < 42; k++) {
		var index = -1;
		for (var i = 0; i < keys.length; i++) {
			if (countries[keys[i]].confirmed.count + countries[keys[i]].deaths.count + countries[keys[i]].recovered.count === cases[k] && !c.includes(keys[i])) {
				index = keys[i];
				break;
			}
		}
		c.push(index);
	}
	for (var i = 0; i < 42; i++) {
		if (i < 42/2) renderCountry(i, c[i], countries[c[i]]);
		else renderCountry(i-21, c[i], countries[c[i]], true);
	}
}
function map(x, a0, a1, b0, b1) {
	return (((b0-b1)/(a0-a1))*(x-a0))+b0;
}
function mapCoords(e) {
	return [map(e[0], 90, -60, 49, 861), map(e[1], -180, 180, 19, 1899)];
}
var a = 53;
function animate() {
	var r = false;
	if (a < 0) {
		a = 53;
		r = true;
	}
	renderDay(a, data);
	a--;
	var link = document.createElement('a');
	link.setAttribute('download', 'frame.png');
	link.setAttribute('href', canvas.toDataURL("image/png").replace("image/png", "image/octet-stream"));
	link.click();
	if (!r) requestAnimationFrame(animate);
}
function renderCountry(id, name, data, side) {
	if (data) {
		side = !side;
		var s = 50;
		ctx.fillStyle = ["black", "#2b2b2b"][id%2];
		if (side) ctx.fillRect(0, 1080+350+(s*id), 1920, s);
		ctx.fillStyle = "white";
		ctx.font = "30px Courier";
		var e = ("" + name).slice(0, 23);
		if (e !== name) name = e + "...";
		ctx.fillText(name, side ? 10 : (1920/2 + 10), 1080+350+(s*id)+s/1.5);
		ctx.fillText("C: " + data.confirmed.count, 500 + (side ? 0 : 1920/2), 1080+350+(s*id)+s/1.5);
		ctx.fillText("R: " + data.recovered.count, 650 + (side ? 0 : 1920/2), 1080+350+(s*id)+s/1.5);
		ctx.fillText("D: " + data.deaths.count, 800 + (side ? 0 : 1920/2), 1080+350+(s*id)+s/1.5);
	}
}